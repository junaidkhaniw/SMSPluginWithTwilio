<h2> <?php esc_attr_e( 'Send message easily', 'WpAdminStyle' ); ?></h2>
<div class="wrap">
    <div class="metabox-holder columns-2">
        <div class="meta-box-sortables ui-sortable">
            <div class="postbox">
                <h2 class="hndle">
                    <span> <?php esc_attr_e( 'SEND SMS', 'WpAdminStyle' ); ?></span>
                </h2>
                <div class="inside">
                    <form id="smsform" method="post" name="cleanup_options" action="">
                        <label>Sender Number</label><br>
                        <input type="text" name="sender" value="<?php echo get_option('sendex')['api_phone_number']; ?>" class="regular-text formInput" placeholder="Sender ID" required /><br><br>
                        <label>User Numbers</label><br>
                        <input type="text" name="numbers" class="regular-text formInput" placeholder="+23480597..." required /><br><br>
                        <label>Message</label><br>
                        <textarea class="formInput" name="message" cols="50" rows="7" placeholder="Message"></textarea><br><br>
                        <input class="button-primary" type="submit" value="SEND MESSAGE" name="send_sms_message" />
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
#smsform label {
    font-size: 16px;
    font-weight: 500;
}
#smsform .formInput {
    margin-top: 5px;
    
}
</style>